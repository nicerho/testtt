function ids(){
	if(f.mid.value==""){
		alert("아이디를 입력하세요");
		return false;
	}else{
		return true;
	}
}